package fr.uge.jee.printers;

public class SimpleMessagePrinter implements MessagePrinter{

    public void printMessage(){
        System.out.println("Hello World!");
    }

}
