package fr.uge.jee.onlineshop;

public class Thief implements Insurance{

    @Override
    public String description() {
        return "Thief insurance";
    }
}
