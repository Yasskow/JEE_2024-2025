package fr.uge.jee.printers;

public interface MessagePrinter {
    void printMessage();
}
