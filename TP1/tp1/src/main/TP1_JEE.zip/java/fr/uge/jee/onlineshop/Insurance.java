package fr.uge.jee.onlineshop;

public interface Insurance {
    String description();
}
