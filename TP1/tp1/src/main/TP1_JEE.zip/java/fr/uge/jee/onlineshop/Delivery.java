package fr.uge.jee.onlineshop;

public interface Delivery {
    String description();
}
